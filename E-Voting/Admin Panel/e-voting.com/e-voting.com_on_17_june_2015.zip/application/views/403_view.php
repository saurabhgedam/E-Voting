<div class="left-sidebar">
            
            <div class="row-fluid page-not-found">
              <div class="span6 number">
                403
              </div>
              <div class="span6">
                <h3>
                  Forbidden or No Permission to Access
                </h3>
                <p>
                  We can not permission to access the page you're looking for.
                  <br>
                  Try the search bar below.
                </p>
                <form>
                  <div class="input-append">
                    
                    <input class="x-large" type="text" placeholder="Search Here">
                    <button class="btn btn-info">
                      Search
                    </button>
                    
                    <a href="index-2.html" class="fs1 icomoon-home-2 " aria-hidden="true" data-icomoon="" style="display: inline-block; margin: 8px;">
                    </a>
                  </div>
                </form>
              </div>
            </div>
            
          </div>