<?php
$this->load->view('includes/htmlheader_view');
$this->load->view($main_content);
//$this->load->view('includes/htmlright_sidebar');
$this->load->view('includes/htmlfooter_view');
?>